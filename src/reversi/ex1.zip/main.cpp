/*
 *  Created on: Oct 28, 2017
 *      Author: Efrat Meir
 *      user name meirefr
 *      ID 201543253
 */

#include <iostream>
#include "Board.h"
using namespace std;

int main() {
	Board b;
	b.print();
	return 0;
}
