/*
 * Sprite.cpp
 */

#include <Sprite.h>
#include <iostream>
using namespace std;


Sprite::~Sprite() {
}

