/*
 * Sprite.cpp
 *
 *  Created on: Nov 3, 2017
 *      Author: efrat
 */

#include "Sprite.h"
#include <iostream>
using namespace std;


Sprite::~Sprite() {
}

