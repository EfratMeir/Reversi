/*
 * ComputerPlayer.cpp
 *
 *  Created on: Nov 3, 2017
 *      Author: Efrat Meir
 *      user name: meirefr
 *      ID: 201543253 */

#include "ComputerPlayer.h"
#include "Player.h"

ComputerPlayer::ComputerPlayer() {
	this->sign = 'X';
}

ComputerPlayer::ComputerPlayer(char sign) {
	this->sign = sign;
}

Point ComputerPlayer::play_one_turn(Board& board) {
}

ComputerPlayer::~ComputerPlayer() {
	// TODO Auto-generated destructor stub
}

vector<Point> ComputerPlayer::get_possible_moves(Board& board,
		MovesCalculator moves_calculator, char this_player_sign) {
}

Point ComputerPlayer::choose_best_move(vector<Point> options_list) {
}

void ComputerPlayer::play_next_step(Board& board, Point chosen_step) {
}
