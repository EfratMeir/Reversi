/*
 * Board.h
 *
 *  Created on: Oct 28, 2017
 *      Author: Efrat Meir
 *      user name meirefr
 *      ID 201543253
 */

#ifndef BOARD_H_
#define BOARD_H_
#include <iostream>
#define SIZE 8
using namespace std;

class Board {
public:

	/**
	 * constructor.
	 */
	Board();
	/**
	 * prints the default game board.
	 */
	void print() const;
	//the game board array
	char arr[SIZE][SIZE];

	static const char black_player = 'X';
	static const char white_player = 'O';
	static const char blank = ' ';

};

#endif /* BOARD_H_ */
