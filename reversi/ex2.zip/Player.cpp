/*
 * Player.cpp
 *
 *  Created on: Nov 3, 2017
 *      Author: Efrat Meir
 *      user name: meirefr
 *      ID: 201543253
 */

#include "Player.h"
#include "Board.h"
#include <iostream>
#include<vector>
using namespace std;
//
//Player::Player() {
//	this->sign;
//	//this->board = Board(0,0); //not initialized
//	this->moves_calculator = MovesCalculator();
//}
//
//Player::Player(Board& board, char sign) {
//	this->sign = sign;
//	//this->board = board;
//	this->moves_calculator = MovesCalculator();
//}
//
Player::~Player() {
	// TODO Auto-generated destructor stub
}


