/*
 * Board.cpp
 *
 *  Created on: Oct 28, 2017
 *      Author: Efrat Meir
 *      user name meirefr
 *      ID 201543253
 */

#include "Board.h"
#include <iostream>
using namespace std;
#define SIZE 8

Board::Board() {

	for (int i = 0; i < SIZE; i++) {
		for (int j = 0; j < SIZE; j++) {
			arr[i][j] = blank;
		}
	}

	//indexes are -1 becauses the array start from 0
	arr[4 - 1][4 - 1] = white_player;
	arr[5 - 1][5 - 1] = white_player;
	arr[4 - 1][5 - 1] = black_player;
	arr[5 - 1][4 - 1] = black_player;

}
void Board::print() const {
	// i - index for rows
	// j - index for columns
	cout << " | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |" << endl
			<< "----------------------------------" << endl;
			for (int i = 0; i < SIZE; i++) {
				for (int j = 0; j < SIZE + 1; j++) {  //size + 1 because  of the rows indexes
					if (j == 0) {
						cout << i + 1;
					}
					if (j == SIZE) {
						cout << "| " << endl <<
								"----------------------------------" << endl;
					}
					else {
						cout << "| " <<arr[i][j] << " ";
					}
				}
			}
}


